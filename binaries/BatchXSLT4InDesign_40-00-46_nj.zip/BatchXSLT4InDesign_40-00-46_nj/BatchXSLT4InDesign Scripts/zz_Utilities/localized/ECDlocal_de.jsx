/*
 * Localized strings for 'ExportCurrentDocument.jsx
 * Language: German - de
 * Version date: 20200118
 *
 * DISCLAIMER:
 * ===============
 * Absolutely no warranty. Use it as is or modify it to match your needs
 * Author: Andreas Imhof, www.aiedv.ch
 */

lg[0]="Dieses Export Script l\u00e4uft nicht mit dieser InDesign Version!\nEs ist ausschliesslich f\u00fcr InDesign CS5 und neuer !\n\nVerarbeitung wird abgebrochen.";

lg[1]="Der Name des 'InDesign IDML' Formates konnte nicht ermittelt werden!\nEditieren Sie die Variable 'inxExportFormatString' in diesem Script und starten Sie es dann erneut!";

lg[2]="Die '" + applicationHumanName + "' Applikation kann nicht gefunden werden!\n\nKopieren Sie bitte die Anwendung in den lokalen 'Programme' oder HOME Ordner (wie im Handbuch beschrieben) oder w\u00e4hlen Sie diese im folgenden Dialog aus!";

lg[3]="Bitte w\u00e4hlen Sie den Ordner mit der '" + tranformerName + "' Anwendung";

lg[4]="Dokumentexport abgebrochen.\n\nDie Anwendung kann mit dem Export nicht fortfahren weil '" + applicationHumanName + "' nicht gefunden werden kann.";

lg[5]="Bitte \u00f6ffnen Sie ein zu exportierendes InDesign Dokument oder Buch und rufen Sie dann dieses Script erneut auf!";

lg[6]="Bitte sichern Sie das Dokument und rufen Sie dann dieses Script erneut auf!";

lg[7]="Die Export Ordner Struktur konnte nicht erstellt werden:\n" + mainExportFolderIn + "\n\nBitte kopieren Sie die 'Export' Ordnerstruktur vom Softwarepaket in Ihren HOME Ordner.";

lg[8]="Wegen der verlangten Auftrennung von Artikeln wurden verkettete Boxen getrennt. Der zuletzt gesicherte Stand des Dokumentes wird wieder hergestellt!";

lg[9]="Basisexport f\u00fcr '" + applicationHumanName + "' in Ordner:\n'%%1%%'\nerstellt.";

lg[10]="\n\n\'" + applicationHumanName + "' wurde gestarted um ePaper zu kreieren.\n\nWechseln Sie zu '" + applicationHumanName + "' und warten Sie die Beendigung ab.\n\nDas Dokument wurde in den Pfad:\n'%%1%%'\nexportiert.\n\n\nAuf 'OK' klicken um diese Meldung zu schliessen";

lg[11]="\nsowie das aktuelle Dokument.";

lg[12]="Dokument Export in Ordner\n\n%%1%%\n\nfehlerhaft beendet. Code %%2%%.";

lg[13]="'" + applicationHumanName + "' konnte nicht gestartet werden!\nStarten Sie es bitte manuell!!";

lg[14]="Exportiere Dokument PDF nach '%%1%%' ...";

lg[15]="Exportiere Dokument zu %%1%% Format ...";

lg[16]="Exportiere PDF und JPEG der Seite #%%1%% ...";

lg[17]="Exportiere JPEG der Seite #%%1%% ...";

lg[18]="Exportiere PDF der Seite #%%1%% ...";

lg[19]="Kopiere %%1%% Bilder ...";

lg[20]="'Jahr' muss aus 4 Zahlen bestehen (JJJJ) wie 2011";

lg[21]="'Datum' muss aus 8 Zahlen bestehen (JJJJMMTT) wie 20110924";

lg[22]="Fehler #%%1%% in Dialog Feldern: %%2%%";

lg[23]="[OK] klicken um das Document zuerst zu sichern oder";

lg[24]="[Abbrechen] klicken um das ungesicherte Dokument zu exportieren.";

lg[25]="## Fehler beim Erstellen des Kommunikationsordners\n" + BXSLT4InDesignCommDir + "\n\nExport fehlerhaft beendet";

lg[26]="Reproduktion %%1%% Bilder ...";

lg[27]="";

lg[28]="";

lg[29]="Dokument Export";

lg[30]="Export Basispfad:";

lg[31]="Firma Name:";

lg[32]="---- Unterordner in 'Export Basis Pfad'";

lg[33]="Objekt Name:";

lg[34]="- Objekt oder Kategorie Name";

lg[35]="Objektk\u00fcrzel:";

lg[36]="- 2 bis 5 Zeichen als K\u00fcrzel";

lg[37]="Jahr:";

lg[38]="- 4 Zahlen Ausgabejahr JJJJ";

lg[39]="Datum:";

lg[40]="- 8 Zahlen Datum JJJJMMTT";

lg[41]="Export Pfad Quelle:";

lg[42]="XML Export Pfad:";

lg[43]="Start Transformer:";

lg[44]="Optionen:";

lg[45]="Bilder, ";

lg[46]="skaliert:";

lg[47]="Seiten JPEGs";

lg[48]="Breite:";

lg[49]="px,";

lg[50]="Seiten PDFs";

lg[51]="Dokument PDF";

lg[52]="in Verkettungen";

lg[53]="Originalbilder kopieren";

lg[54]="Artikelverkettungen trennen:";

lg[55]="NICHT trennen";

lg[56]="Bei Seitenwechsel";

lg[57]="ALLE trennen";

lg[58]="Verkettungen trennen nur in CS3 und neuer!";

lg[59]="Tabellen Optionen:";

lg[60]="keine";

lg[61]="collapse";

lg[62]="separate";

lg[63]="Zellr\u00e4nder";

lg[64]="Faktor Zellengr\u00f6sse";

lg[65]="0 = variabel, 1.0 = beibehalten, 1.3 = Multiplikator";

lg[66]="CSS Name:";

lg[67]="Dokument nach Export schliessen";

lg[68]="Einstellungen speichern";

lg[69]="Export Ordner \u00f6ffnen";

lg[70]="Artikelketten werden aufgetrennt... Bitte warten...";

lg[71]="Dokument neu berechnen... Bitte warten...";

lg[72]="Meldungen zeigen";

lg[73]="Finish Param:";

lg[74]="Settings Pfad:";


lg[75]="Original Seiten-JPEG von InDesign kopieren oder nicht";
lg[76]="Original Seiten-JPEG NICHT kopieren";
lg[77]="Original Seiten-JPEG kopieren";

lg[80]="Faktor Schriftgr\u00f6sse:";


lg[83]="INIT-Datei:";

lg[84]="Settings-Datei nicht erreichbar!";

lg[85]="Originalbilder nicht kopieren";
lg[86]="Alle Originalbilder kopieren";
lg[87]="Nur PDF,JPG,GIF,PNG kopieren";

lg[88]="Nur reine ASCII CSS Klassennamen";

lg[89]="Settings File:";

lg[90]="Fangradius:";
lg[91]="  Kein Artikelfang durch Boxen";
lg[92]="mit Inhalt 'nicht zugewiesen'   ";
lg[93]="die leer sind   ";
lg[94]="Kein Boxfang oder ->";

lg[97]="PRO Attribute exportieren";

lg[98]="Druckb\u00f6gen";

lg[99]="Bilder rotieren";
lg[100]="No";
lg[101]="JPEG";
lg[102]="PNG";
lg[103]="GIF";
lg[104]="TIFF";

lg[105]="ohne versteckte Layer";

lg[106]="Elemente vom Export ausschliessen:";

lg[107]="Alle leeren Boxen";
lg[108]="Leere Text-Boxen";
lg[109]="Leere Bild-Boxen";
lg[110]="Leere Boxen ohne Inhaltstyp";
lg[111]="Linien-Boxen";
lg[112]="Nicht druckende Boxen";

lg[119]="Kein Boxfang";
lg[120]="Kein Boxfang durch";
lg[121]="Boxen ohne zugewiesenen Inhalt";
lg[122]="leeren Boxen";
lg[123]="Text-Boxen";
lg[124]="verkettete Boxen";
lg[125]="Bild-Boxen";


lg[130]="Mouse Overs im Browser unterdr\u00fccken";
lg[131]="ALLE Mouse Overs unterdr\u00fccken";
lg[132]="Auf Text-Boxen";
lg[133]="Auf Bild-Boxen";
lg[134]="Auf leeren Boxen";

lg[139]="Bildnamen ausschliessen:";
lg[140]="Eine durch Semikolon getrennte Liste von Zeichenketten wie 'excl_;555'. Bilder deren Name mit einem dieser Zeichenketten beginnt werden nicht exportiert";

// buttons
lg[141]="Export";
lg[142]="Abbrechen";
lg[143]="Einstellungen laden";
lg[144]="Einstellungen speichern";
lg[145]="Grund-Einstellungen";

// tool tips
lg[150]="Eignername/Firmenname f\u00fcr dieses Objekt - oder leer";
lg[151]="Objektname (kein Leerzeichen) - oder leer";
lg[152]="Objektk\u00fcrzel (2 bis 5 Zeichen)";
lg[153]="Ausgabe Jahr (4 Zahlen JJJJ)";
lg[154]="Ausgabe Datum (8 Zahlen JJJJMMTT)";
// tab marks
lg[155]="Ausgabe Typ";
lg[156]="Bilder";
lg[157]="Boxfang";
lg[158]="Ausschluss";
lg[159]="Tabellen";
lg[160]="Browser Ansicht";
lg[161]="Pfad Infos";
// Tab 1 'Output Mode Tool tips
lg[166]="Einzubindende Ausgabe Transformation";
lg[167]="JPEG Seitenvorschau f\u00fcr Browseransicht";
lg[168]="Breite der JPEG Seitenvorschau in Pixel: 500. Mehrere Seitenbilder getrennt durch '//' wie: 500//800//1000";
lg[169]="PDF von jeder Seite einzeln erstellen und einbinden";
lg[170]="Zu verwendende PDF-Settings f\u00fcr Seiten-PDFs";

lg[171]="PDF vom gesamten Dokument erstellen und einbinden";
lg[172]="Dokument PDF als Arbeitsfl\u00e4chen";
lg[173]="Zu verwendende PDF-Settings f\u00fcr Dokument-PDFs";

lg[174]="PRO Elemente und Attribute exportieren (nur PRO und DEMO-Version)";

lg[175]="Verkettete Textboxen nicht auftrennen";
lg[176]="Verkettete Textboxen Bei Seitenwechsel auftrennen";
lg[177]="Alle verkettete Textboxen auftrennen";
lg[178]="Export InDesign XML";
lg[179]="Export InDesign XML Tags (nur PRO und DEMO-Version)";
lg[180]="PRO Features:";

lg[181]="Bild-Exportformat oder kein Bildexport";
lg[182]="Bildgr\u00f6sse und mehrfach Bilder wie 1.0 oder 1.0[;parameter]//2.0[;parameter]";
lg[183]="Bild Finish Parameter wie: -strip oder -strip -density 300";
lg[184]="Archiv: Originalbilder in Ausgabeordner kopieren";
lg[185]="Bilder drehen wie in InDesign angezeigt";

lg[190]="Fang-Radius: Boxen zum selben Artikel zusammenf\u00fchren wenn n\u00e4her als soviel Pixel";
lg[191]="Kein Boxfang - jede Boxen als Einzelartikel bahandeln";
lg[192]="Kein Einfangen durch Boxen ohne zugewiesenen Inhalt";
lg[193]="Kein Einfangen durch alle leeren Boxen";
lg[194]="Kein Einfangen durch Textboxen";
lg[195]="Kein Einfangen durch verkettete Textboxen";
lg[196]="Kein Einfangen durch Bildboxen";

lg[201]="Inhalt von unsichtbaren Layern unterdr\u00fccken";
lg[202]="Alle leeren Boxen unterdr\u00fccken";
lg[203]="Leere Textboxen unterdr\u00fccken";
lg[204]="Alle leeren Bildboxen unterdr\u00fccken";
lg[205]="Boxen ohne zugewiesenen Inhalt unterdr\u00fccken";
lg[206]="Linien unterdr\u00fccken";
lg[207]="Nicht druckende Boxen unterdr\u00fccken";

lg[211]="Behandlung der Ramen von Tabellenzellen (wie in HTML)";
lg[212]="Gr\u00f6sse von HTML Tabellenzellen";

lg[221]="CSS Name: leer = automatisch - oder ein fixer Nname";
lg[222]="Nur reine ASCII-Zeichen in CSS Klassennamen erlauben";

lg[224]="'Mouse Overs' auf allen Boxen unterdr\u00fccken (Artikel k\u00f6nnen nicht angeklickt werden)";
lg[225]="'Mouse Overs' auf Textboxen unterdr\u00fccken (Text k\u00f6nnen nicht angeklickt werden)";
lg[226]="'Mouse Overs' auf Bildboxen unterdr\u00fccken (Bilder k\u00f6nnen nicht angeklickt werden)";
lg[227]="Kein 'Mouse Overs' auf leeren Boxen";
lg[228]="Anpassung der Schriftgr\u00f6ssen im CSS. Standard ist 1.0 f\u00fcr Originalgr\u00f6sse";

lg[231]="Dokument nach erfolgtem Export schliessen";
lg[232]="Export Ordner nach erfolgtem Export anzeigen";
lg[233]="Statusmeldungen w\u00e4rend des Basisexportes anzeigen";
lg[234]="Aktuelle Einstellungen beim Verlassen dieses Dialogs in der Settingsdatei speichern";

lg[241]="Export mit diesen Einstellungen starten";
lg[242]="Export abbrechen";
lg[243]="Neue Einstellungen von einer Settingsdatei laden";
lg[244]="Diese Einstellungen speichern";
lg[245]="Standard-Einstellungen setzen";

lg[251]="W\u00e4hlen Sie die Settings-Datei";
lg[252]="Sind Sie sicher, dass Sie die Standard-Einstellungen setzen wollen?\nAlle in diesem Dialog gemachten \u00c4nderungen gehen verloren!";
lg[253]="Geben Sie den Namen dieser Settings-Datei an";

lg[260]="Kommunikation Pfad:";

// from 270 - 300 reserved for XML output modes
lg[270]="Ausgabe Modus:";
lg[271]="Bl\u00e4tterbuch XML/HTML";
lg[272]="Seiten-ePaper XML/HTML";
lg[273]="Artikelliste XML/HTML";
lg[274]="Artikelliste Simpel XML/HTML";
lg[275]="XML Baum";
lg[276]="SlidePage eBook";

lg[280]="Bl\u00e4ttern";
lg[281]="Initialer Anzeigemodus im Bl\u00e4tterbuch: bl\u00e4tternde Seiten";
lg[282]="Schieben";
lg[283]="Initialer Anzeigemodus im Bl\u00e4tterbuch: Schiebeseiten";


lg[301]="Datumsformat im Dokumentnamen";

lg[307]="Neuer Hooks Pfad w\u00e4hlen";
lg[308]="Hooks Pfad";
lg[309]="Pfad zu Javascript Plugins (Hooks) auswählen";

lg[310]="Pfad ausw\u00e4hlen f\u00fcr Einstellungsdateien";
lg[311]="Neuer Export Basispfad w\u00e4hlen";
lg[312]="Anw\u00e4hlen um den Transformer " + tranformerName + " zu starten nach erfolgten Basisexport";
lg[313]="Pfad zur Kommunikation mit " + tranformerName + " ausw\u00e4hlen";
lg[314]="Control Transformer";
lg[315]="Anw\u00e4hlen um den Transformer " + tranformerName + " via JobTickets zu steuern";
lg[316]="Source Pfad Transformer";
lg[317]="Maschinen spezifischer 'in' Pfad wie der Transformer ihn sieht";
lg[318]="Output Pfad Transformer";
lg[319]="Maschinen spezifischer 'out' Pfad wie der Transformer ihn sieht";


lg[320]="Seitenvorschau JPEG DPI";
lg[321]="dpi,";
lg[322]="Seitenvorschau JPEG Qualit\u00e4t: 1 - 100";
lg[323]="quality";

lg[330]="Hintergrundbox Schwellenwert:";
lg[331]="Boxen als Seitenhintergrund behandeln, falls deren Gr\u00f6sse gr\u00f6sser ist als dieser Faktor der Originalseite";
lg[332]="Hintergrundboxen ausschliessen:";
lg[333]="Nichts ausschliessen";
lg[334]="Grosse Textboxen ausschliessen";
lg[335]="Grosse Bildboxen ausschliessen";
lg[336]="BEIDE ausscliessen";
lg[337]="Layer ausschliessen: ";
lg[338]="Komma-getrennte Liste von Layernamen die vom Export auszuschliessen sind";

lg[340]="CSS Font Einheit";
lg[341]="pt";
lg[342]="%";
lg[343]="em";

lg[350]="Fontgr\u00f6sse Basis";
lg[351]="Basis Schriftgr\u00f6sse zur Berechnung von relativen Schriftgr\u00f6ssen";


lg[360]="Bild DPI:";
lg[361]="wie 150. default ist 96dpi. Oder input,output DPI wie 300,150";
lg[362]="JPEG Qualit\u00e4t:";
lg[363]="wie 100 oder 60. default ist 90";
lg[364]="Eingangs Parameter:";
lg[365]="wie '-density 300' um das Bild mit 300 dpi einzulesen";
lg[366]="Bilddateien immer \u00fcberschreiben";
lg[367]="Bilder immer konvertieren auch wenn sie schon bestehen";
lg[368]="Bildname mit Pr\u00e4fix";
lg[369]="Eindeutiger Pr\u00e4fix zu Bildname zuf\u00fcgen";
lg[370]="Bild Export:";
lg[371]="Wie Bilder zu exportieren oder fehlende Bilddateien zu behandeln sind";
lg[372]="Bilder immer von der Originaldatei exportieren";
lg[373]="Von Originaldatei, bei fehlenden Originalen von InDesign's Bildbox Vorschau";
lg[374]="Alle Bilder von InDesign's Bildbox Vorschau reproduzieren";
lg[375]="Von Originaldatei, fehlende Originalbilder vom Seiten-JPEG reproduzieren";
lg[376]="Alle Bilder vom Seiten-JPEG reproduzieren";
lg[377]="Metadaten extrahieren";
lg[378]="Metadaten vom Bild extrahieren: title, description, author";
lg[379]="Alle Metadaten";
lg[380]="Alle enthaltenen Metadaten extrahieren";

lg[390]="Website Parameter:";
lg[391]="Liste von keyword=content - getrennt durch *#* -> logoURL=http://www.aiedv.ch*#*logoTitle=www.aiedv.ch*#*logoURLtarget=_blank";

