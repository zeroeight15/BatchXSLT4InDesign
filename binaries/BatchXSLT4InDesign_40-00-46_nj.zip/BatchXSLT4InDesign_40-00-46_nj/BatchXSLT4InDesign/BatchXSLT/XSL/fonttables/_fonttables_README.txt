Font Conversion Tables README
==========================================
Displaying Unicode Fonts in Browsers.

******************************************
You should NOT use fonts whose characters are not defined as Unicodes!
Othewise your documents can not be displayed correctly in a Browser
******************************************

Contact us, if you need a special conversion tables for your fonts: email to ai@aiedv.ch
Usually in cases when you use non Unicode aware, non latin fonts.

------------------------------------------------
The following fonts with special glyphs should not be used in documents for export to internet.
Most glyphs do NOT have a Unicode equivalent and therefore may not be displayed in Browsers:

Some characters of the following fonts are NOT available in Unicode:
- Webdings

Only a few characters of the following fonts are available in Unicode
- Wingdings


------------------------------------------------
The Unicode aware font:
Full Name:        Zapf Dingbats
PostScript Name:  ZapfDingbatsITC
Family:           Zapf Dingbats
Stile:            Regular
Type:             True Type
Language:         
Version:          5.0d2e1
Unique Name:      ITC Zapf Dingbats
Copyright:        (c) Copyright 1999-2000 as an unpublished work by Galapagos Design Group, Inc.

*** is correctly displayed in Safari
*** Firefox has problems with certain Unicode characters. However the exported codes are correct.



------------------------------------------------
The Unicode aware font:
Full Name:        Symbol
PostScript Name:  Symbol
Family:           Symbol
Stile:            Regular
Type:             True Type
Language:         
Version:          5.0d1e1
Unique Name:      Symbol; 5.0d1e1, Wed, Apr 14, 2004
Copyright:        � 1990-99 Apple Computer Inc. � 1990-91 Bitstream Inc.

*** is correctly displayed in Safari
*** Firefox has problems with certain Unicode characters - braces. However the exported codes are correct.



------------------------------------------------
The font:
Full Name:        Mathematical Pi 1
PostScript Name:  MathematicalPi-One
Family:           Mathematical Pi
Stile:            1
Type:             PostScript Type1
Language:         Englisch
Version:          001.000
Unique Name:      Mathematical Pi 1
Copyright:        Copyright (c) 1990 Adobe Systems Incorporated

*** is not a Unicode aware font and needs a conversion table: "Mathematical Pi 1.ftb"



------------------------------------------------
The font:
Full Name:        European Pi 1
PostScript Name:  EuropeanPi-One
Family:           European Pi
Stile:            1
Type:             PostScript Type1
Language:         Englisch
Version:          001.000
Unique Name:      European Pi 1
Copyright:        Copyright (c) 1990 Adobe Systems Incorporated

*** is not a Unicode aware font and needs a conversion table: "European Pi 1.ftb"



------------------------------------------------
The font:
Full Name:        European Pi 3
PostScript Name:  EuropeanPi-Three
Family:           European Pi
Stile:            1
Type:             PostScript Type1
Language:         Englisch
Version:          001.000
Unique Name:      European Pi 3
Copyright:        Copyright (c) 1990 Adobe Systems Incorporated

*** is not a Unicode aware font and needs a conversion table: "European Pi 3.ftb"
