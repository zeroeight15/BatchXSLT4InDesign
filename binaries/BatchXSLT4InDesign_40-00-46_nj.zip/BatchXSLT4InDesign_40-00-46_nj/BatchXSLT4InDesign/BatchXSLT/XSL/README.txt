Usually, you don't need to change anything within this folder directly.
If documentation is unclear - ask me!
Andreas Imhof