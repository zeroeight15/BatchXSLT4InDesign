
var dataflowmove = 15;	    // move x pixels each step
var dataflowinterval = 1;	// move this fast in ms
var hidepos = -10000;
var startpos = -100;
var stoppos = 350;
var nextpos = hidepos;
function show_dataflow() {
	if (nextpos == hidepos) nextpos = startpos;
	nextpos += dataflowmove;
	if (nextpos < stoppos) {
		document.getElementById("dataflow").style.left = nextpos + "px";
		window.setTimeout("show_dataflow()", dataflowinterval);
	} else {	// hide it again
		nextpos = hidepos;
		document.getElementById("dataflow").style.left = hidepos + "px";
	}
}