/*
 ======================================================================
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE PRODUCER OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.

THE PRODUCER:
Andreas Imhof
EDV-Dienstleistungen
CH-Guemligen, Switzerland
www.aiedv.ch

CREATED: 2006
Version: 4.0
Version date: 20061213
======================================================================
*/

var cur_lang = null;	//	language as short text like de fr en - set default to english
var cur_lang_ID = 0;	//	language IDs:
						//	0 = en, 1 = de, 2 = fr, 3 = da ....
var lang_override = "";
try { lang_override = window.location.search.split("=")[1]; } catch(e) {}
//alert("lang_override: " + lang_override);

if ( (lang_override == null) || (lang_override == "") ) {

	try {
		if ((parent.global.override_language != null) && (parent.global.override_language != "")) {
			cur_lang = parent.global.override_language;
		}
	} catch(e){}

	if ((cur_lang == null) || (cur_lang == "")) {
		if (navigator.appName.toUpperCase().indexOf("EXPLORER") > -1) {	// for Internet Explorer
			cur_lang = navigator.userLanguage;
			//alert("Explorer userLanguage: " + cur_lang);
		}
		else {	// for Netscape, Safari
			// like: " Mozilla/5.0 (Macintosh, U; PPC Mac OS X Mach-O; de-DE; rv:1.7.10) Gecko/20050717 Firefox/1.0.6
			// lets filter the 4th part semicolon separated within the ()
			//alert(navigator.userAgent);
			var start = navigator.userAgent.indexOf("(");
			var end = navigator.userAgent.indexOf(")");
			var verstr = navigator.userAgent.substring(start+1,end);
			var parts = verstr.split("; ");
			cur_lang = parts[3].substr(0,2);
			//alert("Netscape language: " + cur_lang);
		}
	}
}
else {
	cur_lang = lang_override;
}
switch (cur_lang) {		// make sure the translated texts are available, otherwise set english
	case "de": cur_lang_ID = 1;
		break;
//	case "fr": cur_lang_ID = 2;
//		break;

	case "en": 
	default:
		cur_lang = "en";
		cur_lang_ID = 0;
		break;
}
//alert("cur_lang: " + cur_lang);




var userAgentString = "" + navigator.userAgent;	// like: "Mozilla/5.0 (Macintosh; U; PPC Mac OS X Mach-O; de; rv:1.8.1) Gecko/20061010 Firefox/2.0"
var is_Windows = false;
var is_IE = false;
var is_IE6 = false;
if (userAgentString.toLowerCase().indexOf("windows") > 0) is_Windows = true;
if (userAgentString.toLowerCase().indexOf("msie") > 0) is_IE = true;
if ((is_Windows == true ) && (is_IE == true)) {
	is_IE6 = is_IE6verison(userAgentString);
}
var img_ext = "png";
if (is_IE6 == true) img_ext = "gif";


// detect explorer version6
function is_IE6verison(useragent) {
	// useragent like: "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5; ......)"
	
	// lets filter the 2nd part semicolon separated within the (     )
	var start = useragent.indexOf("(");
	var end = useragent.indexOf(")");
	var verstr = useragent.substring(start+1,end);
	var parts = verstr.split("; ");

	var versionstr = parts[1];		// like MSIE 6.0
	if (versionstr.indexOf(" 6.") > 0) return(true);

	return(false);
}
