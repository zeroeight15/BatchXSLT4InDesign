/*
 * Localized strings for 'ExportCurrentDocument.jsx
 * Language: English - en
 * Version date: 20200118
 *
 * DISCLAIMER:
 * ===============
 * Absolutely no warranty. Use it as is or modify it to match your needs
 * Author: Andreas Imhof, www.aiedv.ch
 */

lg[0]="This export script may not run with this version of InDesign!\nIt is designed to work with InDesign CS5 and newer !\n\nProcessing aborted.";

lg[1]="The name of the 'InDesign IDML' Format could not be detected!\nPlease, edit the 'inxExportFormatString' variable in this script and try again!";

lg[2]="The '" + applicationHumanName + "' application can not be found!\n\nPlease, copy the application to your local 'Applications' or HOME folder (as mentioned in the manual) or choose the application in the following dialog and try again!";

lg[3]="Please select the folder containing the '" + tranformerName + "' application";

lg[4]="Document export aborted.\n\nThe application may not continue exporting your document because the '" + applicationHumanName + "' application may not be found.";

lg[5]="Please, open an InDesign document or book to export and re-call this script!";

lg[6]="Please, save the document and then re-call this script!";

lg[7]="The export folder structure could not be created:\n" + mainExportFolderIn + "\n\nPlease, copy the 'Export' folder structure from the software package to your HOME folder.";

lg[8]="Due to the requested story splitting, the document's text frame chains probably are split. The document is now reverted to the last saved version!";

lg[9]="Base Export for '" + applicationHumanName + "' to Folder:\n'%%1%%'\ncomplete.";

lg[10]="\n\n'" + applicationHumanName + "' has been started to create ePaper.\n\nSwitch to '" + applicationHumanName + "' and await completion.\n\nThe document has been exported to the path:\n'%%1%%'\n\n\nClick the 'OK' button to close this message";

lg[11]="\nand the current document.";

lg[12]="Document export to folder\n\n%%1%%\n\nfailed. Code %%2%%.";

lg[13]="'" + applicationHumanName + "' could not be started!\nStart it manually!!";

lg[14]="Exporting document PDF to '%%1%%' ...";

lg[15]="Exporting Document to %%1%% Format ...";

lg[16]="Exporting PDF and JPEG of page #%%1%% ...";

lg[17]="Exporting JPEG of page #%%1%% ...";

lg[18]="Exporting PDF of page #%%1%% ...";

lg[19]="Copying %%1%% images ...";

lg[20]="'Year' field must contain 4 digits (YYYY) like 2011";

lg[21]="'Date' field must contain 8 digits (YYYYMMDD) like 20110924";

lg[22]="Error #%%1%% in Dialog fields: %%2%%";

lg[23]="Press [OK] button to return and save the document manually or";

lg[24]="Press [Cancel] button to continue exporting the unsaved document.";

lg[25]="## An error ocurred while creating the communication folder\n" + BXSLT4InDesignCommDir + "\n\nExport failed";

lg[26]="Reproducing %%1%% images ...";

lg[27]="";

lg[28]="";

lg[29]="Document Export";

lg[30]="Export Base Path:";

lg[31]="Company Name:";

lg[32]="---- Add subfolders to 'Export Base Path'";

lg[33]="Object Name:";

lg[34]="- Object or category name";

lg[35]="Object Shortcut:";

lg[36]="- 2 to 5 characters object shortcut";

lg[37]="Year:";

lg[38]="- 4 digits issue year YYYY";

lg[39]="Date:";

lg[40]="- 8 digits full date YYYYMMDD";

lg[41]="Source Export Path:";

lg[42]="XML Export Path:";

lg[43]="Start Transformer:";

lg[44]="Options:";

lg[45]="Images, ";

lg[46]="scale by:";

lg[47]="Page JPEGs";

lg[48]="at width:";

lg[49]="px,";

lg[50]="Page PDFs";

lg[51]="Document PDF";

lg[52]="in chaines";

lg[53]="Copy original image files";

lg[54]="Story frames splitting:";

lg[55]="NO splitting";

lg[56]="Split at page change";

lg[57]="Split ALL chained frames";

lg[58]="Story splitting available in CS3 and above only!";

lg[59]="Table Options:";

lg[60]="nothing";

lg[61]="collapse";

lg[62]="separate";

lg[63]="Cell frames";

lg[64]="Cell resize factor";

lg[65]="0 = floating cell widths, 1.0 = retain, 1.3 = size by";

lg[66]="CSS Name:";

lg[67]="Close document after export";

lg[68]="Save these settings";

lg[69]="Show Export Folder";

lg[70]="Splitting stories... Please wait...";

lg[71]="Recomposing document... Please wait...";

lg[72]="Show Messages";

lg[73]="Finish Param:";

lg[74]="Settings Path:";


lg[75]="Copy/Don't Copy Original Page-JPEG exported from InDesign";
lg[76]="Don't Copy Original Page-JPEG";
lg[77]="Copy Original Page-JPEG";

lg[80]="Font Resize Factor:";


lg[83]="INIT File:";

lg[84]="Settings file not reachable!";

lg[85]="Don't copy original images";
lg[86]="Copy all original images";
lg[87]="Copy PDF,JPG,GIF,PNG only";

lg[88]="Plain ASCII only in CSS class names";

lg[89]="Settings File:";

lg[90]="Catch Radius:";
lg[91]="  Boxes don't catch if:";
lg[92]="'unassigned' content   ";
lg[93]="empty   ";
lg[94]="No Box catching or ->";

lg[97]="Export PRO Attributes";

lg[98]="Spreads";

lg[99]="Rotate Images";
lg[100]="No";
lg[101]="JPEG";
lg[102]="PNG";
lg[103]="GIF";
lg[104]="TIFF";

lg[105]="exclude hidden Layers";

lg[106]="Exclude Elements from Export:";

lg[107]="All empty Boxes";
lg[108]="Empty Text Boxes";
lg[109]="Empty Image Boxes";
lg[110]="Empty Unassigned Boxes";
lg[111]="Line Boxes";
lg[112]="Non Printing Boxes";

lg[119]="No Box Catching";
lg[120]="No Catching through";
lg[121]="boxes with unassigned content";
lg[122]="empty boxes";
lg[123]="text boxes";
lg[124]="chained boxes";
lg[125]="image boxes";


lg[130]="Suppress Mouse Overs in Browser";
lg[131]="Suppress ALL mouse overs";
lg[132]="On Text Boxes";
lg[133]="On Image Boxes";
lg[134]="On Empty Boxes";

lg[139]="Exclude Image Names:";
lg[140]="A semicolon delimited list of strings like 'excl_;555'. Images names starting with one of these patterns will not be exported";

// buttons
lg[141]="Export";
lg[142]="Cancel";
lg[143]="Load Settings";
lg[144]="Save Settings";
lg[145]="Default Settings";

// tool tips
lg[150]="Company name owning this object - or empty";
lg[151]="Name of this object (no spaces) - or empty";
lg[152]="Object's shortcut (2 to 5 chars)";
lg[153]="Issue year (4 digits YYYY)";
lg[154]="Issue full date (8 digits YYYYMMDD)";
// tab marks
lg[155]="Output Types";
lg[156]="Images";
lg[157]="Box Catching";
lg[158]="Excludes";
lg[159]="Tables";
lg[160]="Browser View";
lg[161]="Path Infos";
// Tab 1 'Output Mode Tool tips
lg[166]="Output Transform to integrate";
lg[167]="Page preview JPEG to create for browser view";
lg[168]="Width of page preview JPEG in pixels: 500. Multiple page image sizes separated by '//' like: 500//800//1000";
lg[169]="Create and link a PDF of every single page";
lg[170]="PDF settings to use for single page PDFs";

lg[171]="Create and link a PDF of the entire document";
lg[172]="Create document PDF from spread";
lg[173]="PDF settings to use for document PDFs";

lg[174]="Export PRO features and attributes (PRO and DEMO version only)";

lg[175]="Do NOT split chained text boxes at all";
lg[176]="Split chained text boxes when crossing the page boundary";
lg[177]="Split ALL chained text boxes";
lg[178]="Export InDesign XML";
lg[179]="Export InDesign XML tags (PRO and DEMO version only)";
lg[180]="PRO Features:";

lg[181]="Images export format - or don't export images";
lg[182]="Image size and multiple images export like 1.0 or 1.0[;parameters]//2.0[;parameters]";
lg[183]="Image finishing parameters like: -strip or -strip -density 300";
lg[184]="Archive: Copy original images to output folder";
lg[185]="Rotate converted images like seen in InDesign";

lg[190]="Catch Radius: merge boxes to same article when closer than this amount of pixels";
lg[191]="No box catching at all - treat every box as it's own article";
lg[192]="Boxes with unassigned content don't catch";
lg[193]="All empty boxes don't catch";
lg[194]="Text boxes don't catch";
lg[195]="Chained text boxes don't catch";
lg[196]="Image boxes don't catch";

lg[201]="Don't export content on invisible layers";
lg[202]="Don't export all empty boxes";
lg[203]="Don't export all empty text boxes";
lg[204]="Don't export all empty image boxes";
lg[205]="Don't export boxes with unassigned content";
lg[206]="Don't export line boxes";
lg[207]="Don't export non printing boxes";

lg[211]="How to treat table cell frames (like in HTML)";
lg[212]="Size of HTML table cells";

lg[221]="CSS name: empty = auto - or any fixed name";
lg[222]="Allow plain ASCII characters only in CSS class names";

lg[224]="Suppress all mouse over on all boxes (can not click on any article)";
lg[225]="Suppress mouse over on text boxes (can not click on text)";
lg[226]="Suppress mouse over on image boxes (can not click on images)";
lg[227]="Suppress mouse over empty boxes";
lg[228]="Factor to resize fonts in CSS. Default is original size 1.0";

lg[231]="Close document after base export is done";
lg[232]="Show the export folder after base export is done";
lg[233]="Show status messages during base export";
lg[234]="Save the current settings into the settings file when leaving this dialog";

lg[241]="Start Export with these settings";
lg[242]="Cancel Export";
lg[243]="Load new settings from settings file";
lg[244]="Save these settings to file";
lg[245]="Revert to factory settings";

lg[251]="Choose a Settings File";
lg[252]="Are you sure to revert to default factory settings?\nChanges made in this dialog will be lost!";
lg[253]="Enter the name of this Settings File";

lg[260]="Communication Path:";


// from 270 - 300 reserved for XML output modes
lg[270]="Output Mode:";
lg[271]="Flip Page eBook XML/HTML";
lg[272]="Pages ePaper XML/HTML";
lg[273]="Article List XML/HTML";
lg[274]="Article List Simple XML/HTML";
lg[275]="XML Tree";
lg[276]="Sliding Pages eBook";

lg[280]="Turn pages";
lg[281]="Initial view mode for Flip Page eBook: turning pages";
lg[282]="Slide pages";
lg[283]="Initial view mode for Flip Page eBook: sliding pages";


lg[301]="Date format in document file name";

lg[307]="Choose new path to Javascript Plugins (Hooks)";
lg[308]="Hooks Path";
lg[309]="Choose the path to Javascript Plugins (Hooks)";

lg[310]="Choose new path for settings files";
lg[311]="Choose new export base path";
lg[312]="Check to start the transformer " + tranformerName + " after base export is done";
lg[313]="Choose new path for communicating with " + tranformerName;
lg[314]="Control Transformer";
lg[315]="Check to control the transformer " + tranformerName + " through JobTickets";
lg[316]="Source Path Transformer";
lg[317]="Set the machine specific 'in' path like the transformer does see it";
lg[318]="Output Path Transformer";
lg[319]="Set the machine specific 'out' path like the transformer does see it";


lg[320]="Page preview JPEG DPI";
lg[321]="dpi,";
lg[322]="Page preview JPEG quality: 1 - 100";
lg[323]="quality";

lg[330]="Page background threshold:";
lg[331]="Treat a box as page background when it's size is larger than the given factor of the original page size";
lg[332]="Exclude page background boxes:";
lg[333]="Export normal";
lg[334]="Exclude text boxes";
lg[335]="Exclude image boxes";
lg[336]="Exclude BOTH";
lg[337]="Exclude Layers: ";
lg[338]="A comma separated list of layer names to exclude from export";

lg[340]="CSS font size units";
lg[341]="pt";
lg[342]="%";
lg[343]="em";

lg[350]="Font size base";
lg[351]="Base size to calculate relative font sizes from";

lg[360]="Image DPI:";
lg[361]="like 150. default is 96dpi. Or input,output DPI like 300,150";
lg[362]="JPEG Quality:";
lg[363]="like 100 or 60. default is 90";
lg[364]="Input Parameters:";
lg[365]="like '-density 300' to read in the image at 300 dpi";
lg[366]="Overwrite existing target image";
lg[367]="Always recreate target image even if it already exists";
lg[368]="Ad unique prefix to target image name";
lg[369]="Ad a prefix to image name to make it unique";
lg[370]="Image export:";
lg[371]="How to convert images or extract missing images";
lg[372]="Convert images from original source image files only";
lg[373]="From image file, missing images from InDesign image box preview";
lg[374]="Reproduce ALL images from InDesign image box preview";
lg[375]="From image file, reproduce missing images from page JPEG preview";
lg[376]="Reproduce all images from preview";
lg[377]="Extract Meta data";
lg[378]="Extract Meta data from image: title, description, author";
lg[379]="Full Meta data";
lg[380]="Extract entire Meta data information";

lg[390]="Web Site Parameters:";
lg[391]="a list of keyword=content - separated by *#* -> logoURL=http://www.aiedv.ch*#*logoTitle=www.aiedv.ch*#*logoURLtarget=_blank";

