/*
 * Localized strings for 'ExportCurrentDocument.jsx
 * Language: French - fr
 * Version date: 20200118
 *
 * DISCLAIMER:
 * ===============
 * Absolutely no warranty. Use it as is or modify it to match your needs
 * Author: Andreas Imhof, www.aiedv.ch
 */

lg[0]="Ce script ne fonctionne pas sous cette version de InDesign!\nIl est con\u00e7u pour fonctionner avec InDesign CS5 ou plus r\u00e9cent !\n\nOp\u00e9ration annulu00e9e.";

lg[1]="Le nom du format 'InDesign IDML' n'a pa pu \u00eatre d\u00e9tect\u00e9!\nVeuillez \u00e9diter la variable 'inxExportFormatString' du script et r\u00e9essayer!";

lg[2]="L'application '" + applicationHumanName + "' ne peut pas \u00eatre trouv\u00e9e!\n\nVeuillez copier l'application dans votre dossier 'Applications' ou dans votre r\u00epertoire HOME  (voir le manuel) ou choisissez l'application dans la bo\u00eete de dialogue suivante et r\u00e9essayez!";

lg[3]="Veuillez choisir le dossier qui contient l'application '" + tranformerName + "'";

lg[4]="Export de documents annul\u00e9.\n\nL'application ne peut pas poursuivre l'export de vos documents parce que '" + applicationHumanName + "' ne peut pas \u00eatre trouv\u00e9.";

lg[5]="Veuillez ouvrir un fichier InDesign ou un livre que vous voulez exporter et relancez le script!";

lg[6]="Veuillez enregistrer le document et relancer le script!";

lg[7]="La structure du r\u00e9pertoire export n'a pas pu \u00eatre cr\u00e9\u00e9e:\n" + mainExportFolderIn + "\n\nVeuillez copier coller la structure du r\u00e9pertoire 'Export' de votre pack logiciel dans votre r\u00e9pertoire HOME.";

lg[8]="Suite \u00e0 la s\u00e9paration demand\u00e9e des articles, des blocs de texte li\u00e9s ont \u00e9t\u00e9 s\u00e9par\u00e9s. L'\u00e9tat d'origine du fichier a \u00e9t\u00e9 r\u00e9tabli!";

lg[9]="Etabli l'export de base pour '" + applicationHumanName + "' dans le r\u00e9pertoire:\n'%%1%%'";

lg[10]="\n\n'" + applicationHumanName + "' a \u00e9t\u00e9 lanc\u00e9 pour cr\u00e9er un ePaper.\n\nPassez \u00e0 '" + applicationHumanName + "' et attendez l'ach\u00e8vement.\n\nLe document a \u00e9t\u00e9 export\u00e9 au r\u00e9pertoire:\n'%%1%%'\n\n\nCliquez sur 'OK' pour fermer ce message";

lg[11]="\net le document actuel.";

lg[12]="L'export du document dans le fichier\n\n%%1%%\n\na \u00e9chou\u00e9. Code %%2%%.";

lg[13]="'" + applicationHumanName + "' n'a pas r\u00e9ussi \u00e0 d\u00e9marrer correctement!\nLancez l'application manuellement!!";

lg[14]="Export du document pdf \u00e0 l'emplacement '%%1%%' ...";

lg[15]="Export du document au format %%1%% ...";

lg[16]="Export des PDF et JPEG des pages #%%1%% ...";

lg[17]="Export des JPEG de la page #%%1%% ...";

lg[18]="Export du PDF de la page #%%1%% ...";

lg[19]="Copier %%1%% images ...";

lg[20]="'Ann\u00e9e' en 4 caract\u00e8res (YYYY) like 2011";

lg[21]="'Date' en 8 caract\u00e8res (YYYYMMDD) like 20110924";

lg[22]="Erreur #%%1%% dans les champs de dialogue: %%2%%";

lg[23]="Cliquez sur le bouton [OK] pour retourner et enregistrer le document manuellement ou";

lg[24]="Cliquez sur le bouton [Annuler] pour poursuivre l'export du document non enregistr\u00e9.";

lg[25]="## Un erreur s'est produit lors de la cr\u00e9ation du fichier de communication\n" + BXSLT4InDesignCommDir + "\n\nexport non r\u00e9ussi";

lg[26]="Reproduction %%1%% images ...";

lg[27]="";

lg[28]="";

lg[29]="Export du document";

lg[30]="Chemin de l'export:";

lg[31]="Nom de l'\u00e9tablissement:";

lg[32]="---- Sous-r\u00e9pertoire du r\u00e9pertoire 'Chemin d'acc\u00e8s de l'export'";

lg[33]="Nom de l'objet:";

lg[34]="- Nom de l'objet ou de la cat\u00e9gorie";

lg[35]="Raccourci de l'objet:";

lg[36]="- 2 \u00e0 5 caract\u00e8res formant le raccourci";

lg[37]="Ann\u00e9e:";

lg[38]="- 4 chiffres ann\u00e9e de parution AAAA";

lg[39]="Date:";

lg[40]="- 8 chiffres date AAAAMMJJ";

lg[41]="Chemin source de l'export:";

lg[42]="Chemin de XML Export:";

lg[43]="Start transformateur:";

lg[44]="Options:";

lg[45]="Images, ";

lg[46]="\u00e9chelle:";

lg[47]="JPEGs de la page";

lg[48]="Largeur:";

lg[49]="px,";

lg[50]="PDFs de la page";

lg[51]="PDF du document";

lg[52]="Blocs de texte li\u00e9s";

lg[53]="Copier l'image originale";

lg[54]="Rompre les liens des articles:";

lg[55]="Ne pas rompre les liens";

lg[56]="Rompre en bas de page";

lg[57]="Rompre tous les liens";

lg[58]="Suppression des liens seulement en CS3 et ult\u00e9rieur!";

lg[59]="Options de tableau:";

lg[60]="aucune";

lg[61]="r\u00e9duire";

lg[62]="s\u00e9parer";

lg[63]="cadres de cellule";

lg[64]="Facteur de redimensionnement de la cellule";

lg[65]="0 = largeur des cellules flottantes, 1.0 = conserver, 1.3 = multiplicateur";

lg[66]="Nom du CSS:";

lg[67]="Fermer le document apr\u00e8s l'export";

lg[68]="Enregistrer les param\u00e8tres";

lg[69]="Afficher le dossier 'export'";

lg[70]="Suppression des liaisons... Veuillez patienter...";

lg[71]="Assemblage du document... Veuillez patienter...";

lg[72]="Afficher les messages";

lg[73]="Finish Param:";

lg[74]="Chemin des param\u00e8tres:";


lg[75]="Copier / ou ne pas copier les JPEG des pages exportées depuis InDesign";
lg[76]="Ne pas copier les pages JPEG originales";
lg[77]="Copier les pages JPEG originales";

lg[80]="Facteur taille des charact\u00e8res:";


lg[83]="Fichier INIT:";

lg[84]="Fichier de configuration pas disponible!";

lg[85]="Ne pas copier les images originales";
lg[86]="Copier toutes les images originales ";
lg[87]="Ne copier que PDF,JPG,GIF,PNG";

lg[88]="Noms de classes CSS en code ASCII";

lg[89]="Fichier de configuration:";

lg[90]="Rayon d'accrochage:";
lg[91]="  Aucun accrochage si le contenu du bloc est:";
lg[92]="non attribu\u00e9   ";
lg[93]="vide   ";
lg[94]="Aucun accrochage ou ->";

lg[97]="Export des attributs PRO";

lg[98]="Planches";

lg[99]="Tourner les graphiques";
lg[100]="No";
lg[101]="JPEG";
lg[102]="PNG";
lg[103]="GIF";
lg[104]="TIFF";

lg[105]="exclure les calques masqu\u00e9s";

lg[106]="El\u00e9ments \u00e0 exclure de l'export:";

lg[107]="tous les blocs vides";
lg[108]="les blocs de texte vides";
lg[109]="Les blocs graphiques vides";
lg[110]="Les blocs non attribu\u00e9s vides";
lg[111]="Les blocs de trac\u00e9";
lg[112]="Les blocs non imprimables";

lg[119]="Aucun accrochage de blocs";
lg[120]="Aucun accrochage de blocs";
lg[121]="avec un contenu non attribu\u00e9";
lg[122]="vides";
lg[123]="de texte";
lg[124]="li\u00e9s";
lg[125]="graphiques";


lg[130]="Supprimer les mouseovers dans le navigateur";
lg[131]="Supprimer toutes les mouseovers";
lg[132]="des blocs de texte";
lg[133]="des blocs graphiques";
lg[134]="des blocs non attribu\u00e9s";

lg[139]="Exclure noms:";
lg[140]="Une list de mot-clefs s\u00e9par\u00e9 de point virgule comme 'excl_;555'. Un image dont nom commence avec un des mot-clefs n'est pas export\u00e9";

// buttons
lg[141]="Export";
lg[142]="Annuler";
lg[143]="Chargement des param\u00e8tres";
lg[144]="Enregistrer les param\u00e8tres";
lg[145]="Param\u00e8tres par d\u00e9faut";

// tool tips
lg[150]="Propri\u00e9taire de l'objet - ou laisser vide";
lg[151]="Nom de l'objet (sans espace) - ou laisser vide";
lg[152]="Raccourci de l'objet (2 \u00e0 5 caract\u00e8res)";
lg[153]="Ann\u00e9e de parution (4 chiffres AAAA)";
lg[154]="Date de parution (8 chiffres AAAAMMJJ)";
// tab marks
lg[155]="Type de sortie";
lg[156]="Images";
lg[157]="Accrochage";
lg[158]="Exclusions";
lg[159]="Tableaux";
lg[160]="Vue web";
lg[161]="Chemin d'acc\u00e8s";
// Tab 1 'Output Mode Tool tips
lg[166]="Transformation de sortie \u00e0 int\u00e9grer";
lg[167]="Aper\u00e7u JPEG de la page pour vue web";
lg[168]="Largeur en pixel de l'aper\u00e7u JPEG de la page: 500. Plusieurs tailles d'image des pages s\u00e9par\u00e9es par '//' comme: 500//800//1000";
lg[169]="Cr\u00e9er et relier un PDF de chaque page";
lg[170]="Param\u00e8tres \u00e0 appliquer aux PDFs des pages";

lg[171]="Cr\u00e9er et relier un PDF du document";
lg[172]="Cr\u00e9er un PDF du document en planches";
lg[173]="Param\u00e8tres \u00e0 appliquer aux PDFs du document";

lg[174]="Export des fonctions et attributs PRO (Seulement version PRO et DEMO)";

lg[175]="Ne rompre aucun bloc de texte li\u00e9";
lg[176]="Rompre les blocs de texte li\u00e9s en bas de page";
lg[177]="Rompre tous les blocs de texte li\u00e9s";
lg[178]="Export des InDesign XML";
lg[179]="Export des InDesign XML tags (Seulement version PRO et DEMO)";
lg[180]="Fonctions PRO:";

lg[181]="Format d'export des images - aucun export d'images";
lg[182]="Dimensions des images et export d'images multiples comme 1.0 ou 1.0[;parametres}//2.0[;parametres]";
lg[183]="Param\u00e8tres de finition d'image comm: -strip ou -strip -density 300";
lg[184]="Archive: Copier les images originales dans le dossier de sortie";
lg[185]="Torurner les graphiques";

lg[190]="Rayon d'accrochage: Assemblage des blocs plus pr\u00e8s que ce nombre de pixels \u00e0 un article";
lg[191]="Pas d'accrochage - traiter chaque bloc comme article unique";
lg[192]="Aucun accrochage par des blocs sans contenu attribu\u00e9";
lg[193]="Aucun accrochage par des blocs vides";
lg[194]="Aucun accrochage par des blocs de texte";
lg[195]="Aucun accrochage par des blocs de texte li\u00e9s";
lg[196]="Aucun accrochage par des blocs graphiques";

lg[201]="Ne pas exporter le contenu des calques invisibles";
lg[202]="Ne pas exporter les blocs vides";
lg[203]="Ne pas exporter les blocs de texte vides";
lg[204]="Ne pas exporter les blocs graphiques vides";
lg[205]="Ne pas exporter les blocs sans contenu attribu\u00e9";
lg[206]="Ne pas exporter les trac\u00e9s";
lg[207]="Ne pas exporter les blocs non imprimables";

lg[211]="Traitement des cadres autour des cellules du tableau (comme en HTML)";
lg[212]="Taille des cellules d'un tableau HTML";

lg[221]="CSS nom: vide = auto - ou un nom fixe";
lg[222]="N'autoriser que des noms de classes CSS en code ASCII";

lg[224]="Supprimer toutes les mouseovers de tous les blocs (Aucun clic sur un article n'est possible)";
lg[225]="Supprimer toutes les mouseovers des blocs de texte (Aucun clic sur le texte n'est possible)";
lg[226]="Supprimer toutes les mouseovers des blocs graphiques (Aucun clic sur l'image n'est possible)";
lg[227]="Supprimer toutes les mouseovers des blocs vides";
lg[228]="R\u00e9ajustement de la taille des caract\u00e8res au CSS. Valuer implicite est 1.0";

lg[231]="Fermer le document une fois l'export effectu\u00e9";
lg[232]="Afficher le dossier 'Export' une fois l'export effectu\u00e9";
lg[233]="Afficher les messages d'\u00e9tat pendant l'op\u00e9ration d'export";
lg[234]="Enregistrer les param\u00e8tres actuels \u00e0 la fermeture de cette boite de dialogue";

lg[241]="Lancer l'export en utilisant ces param\u00e8tres";
lg[242]="Annuler l'export";
lg[243]="Charger les nouveaux param\u00e8tres depuis le fichier de configuration";
lg[244]="Enregistrer ces param\u00e8tres";
lg[245]="Restaurer les param\u00e8tres par d\u00e9faut";

lg[251]="Choisir un fichier de configuration";
lg[252]="Voulez-vous vraiment restaurer les param\u00e8tres par d\u00e9faut?\n Vous perdez toutes vos modifications faites dans ce dialogue!";
lg[253]="Entrez le nom de ce fichier de configuration";

lg[260]="Chemin communication:";

// from 270 - 300 reserved for XML output modes
lg[270]="Mode de sortie:";
lg[271]="Flip Page eBook XML/HTML";
lg[272]="Pages ePaper XML/HTML";
lg[273]="liste des articles XML/HTML";
lg[274]="Liste des articles simple XML/HTML";
lg[275]="arborescence XML";
lg[276]="SlidePage eBook";

lg[280]="Pages \u00e0 feuilleter";
lg[281]="Mode d'affichage initiale du Flip Page eBook: feuilleter les pages";
lg[282]="Pages glissantes";
lg[283]="Mode d'affichage initiale du Flip Page eBook: glisser les pages";


lg[301]="Format de date au nom du document";

lg[307]="Choisir le classeur Hooks";
lg[308]="Classeur Hooks";
lg[309]="Choisir le classeur de Javascript Plugins (Hooks)";

lg[310]="Choisir le classeur pour les fichiers param\u00e8tres";
lg[311]="Choisir le classeur export de base";
lg[312]="Activer pour starter le transformateur " + tranformerName + " apr\u00e8s l'export de base";
lg[313]="Choisir le chemin d'acc\u00e8s de communiquer avec " + tranformerName;
lg[314]="Controller tansformateur";
lg[315]="Activer pour controller le tansformateur " + tranformerName + " par JobTickets";
lg[316]="Chemin source transformateur";
lg[317]="Chemin au classeur 'in' du point de vu du transformateur sur sa machine";
lg[318]="Chemin export transformateur";
lg[319]="Chemin au classeur 'out' du point de vu du transformateur sur sa machine";


lg[320]="Aper\u00e7u JPEG de la page JPEG DPI";
lg[321]="dpi,";
lg[322]="Aper\u00e7u JPEG de la page JPEG qualit\u00e9: 1 - 100";
lg[323]="qualit\u00e9";

lg[330]="Valeur seuil de cadres de fond:";
lg[331]="Traiter des grands cadres comme fond de opage, si la largeur es plus grand que ce facteur de la page originale";
lg[332]="Exclure cadres fond de page:";
lg[333]="Rien exclure";
lg[334]="Exclure grands cadres texte";
lg[335]="Exclure grands cadres image";
lg[336]="Exclure les deux";
lg[337]="Exclure calques: ";
lg[338]="Une list de calques \u00e0 exclure, s\u00e9par\u00e9 par virgules";

lg[340]="CSS unite taille des caract\u00e8res";
lg[341]="pt";
lg[342]="%";
lg[343]="em";

lg[350]="Taille de base";
lg[351]="Taille de base pour la calculation des tailles de caract\u00e8res relatives";


lg[360]="DPI image:";
lg[361]="comme 150. d\u00e9faut 96dpi. Ou DPI entr\u00e9e,sortie come 300,150";
lg[362]="Qualit\u00e9 JPEG:";
lg[363]="comme 100 ou 60. defaut est 90";
lg[364]="Parameters entr\u00e9e:";
lg[365]="comme '-density 300' pour lire l'image avec 300 dpi";
lg[366]="Toujours actualiser le fichier image";
lg[367]="Toujours remplacer l'image existente";
lg[368]="Nom du fichier image avec pr\u00e9fixe";
lg[369]="Ajouter un pr\u00e9fixe unique au nom du fichier image";
lg[370]="Exportation des graphiques:";
lg[371]="Mode de conversion de graphiques ou de traitement des graphiques manquants";
lg[372]="Exportation uniquement \u00e0 partir de l'image source originale";
lg[373]="Exportation \u00e0 partir de l'image source, exportation des images manquantes \u00e0 partir de l'aper\u00e7u InDesign";
lg[374]="Reproduction de toutes les images \u00e0 partir de l'aper\u00e7u InDesign";
lg[375]="Reproduction \u00e0 partir de l'image source, les images manquantes \u00e0 partir de l'aper\u00e7u de la page en mode JPEG ";
lg[376]="Reproduire toutes les images \u00e0 partir de l'aper\u00e7u de la page en mode JPEG ";
lg[377]="Extraire les informations meta";
lg[378]="Extraire les informations meta: title, description, author";
lg[379]="Meta enti\u00e8re";
lg[380]="Extraire tout les informations meta";

lg[390]="Param\u00e8tres site:";
lg[391]="une liste de keyword=content - s\u00e9par\u00e9 par *#* -> logoURL=http://www.aiedv.ch*#*logoTitle=www.aiedv.ch*#*logoURLtarget=_blank";

