#!/bin/sh
BASEDIR="$( dirname "$0")"
cd "$BASEDIR"
echo "Base Dir: $BASEDIR"
export JAVA_HOME=$BASEDIR/BatchXSLT.app/Contents/Plugins/JavaVM.app/Contents/Home

BatchXSLT.app/Contents/Plugins/JavaVM.app/Contents/Home/bin/java -Xms384m -Xss12m -Dfile.encoding=UTF8 -jar BatchXSLT.app/Contents/Java/BatchXSLT.jar
